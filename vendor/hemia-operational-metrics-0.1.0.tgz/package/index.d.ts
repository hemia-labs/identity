export declare function installMetrics(app: any, options: {
  service: string;
  dataSource: any;
  checks?: Record<string, () => unknown | Promise<unknown>>;
  outbox?: boolean;
}): Promise<{registry: any; close: () => void} | undefined>;
