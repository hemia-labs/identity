const { createServer } = require('node:http');
const { timingSafeEqual } = require('node:crypto');
const { Registry, Histogram, Gauge, collectDefaultMetrics } = require('prom-client');

// Separate listener: never exposes metrics through the public application router.
async function installMetrics(app, { service, dataSource, checks = {}, outbox = false }) {
  if (!process.env.METRICS_PORT) return;
  const port = Number(process.env.METRICS_PORT);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw Error('Invalid METRICS_PORT');
  const host = process.env.METRICS_HOST || '127.0.0.1';
  const token = process.env.METRICS_TOKEN;
  if (!token || token.length < 32) throw Error('METRICS_TOKEN must contain at least 32 characters');
  const registry = new Registry();
  registry.setDefaultLabels({ service });
  collectDefaultMetrics({ register: registry });
  const histogram = new Histogram({ name: 'hemia_http_request_duration_seconds', help: 'HTTP duration including authentication; route templates only.', labelNames: ['method','route','status'], buckets: [.01,.025,.05,.1,.25,.5,1,2,5,10,30], registers:[registry] });
  app.use((req,res,next) => {
    const start = process.hrtime.bigint(); let done = false;
    const record = () => { if(done) return; done=true;
      const route = typeof req.route?.path === 'string' ? req.route.path : 'unmatched';
      const method = ['GET','HEAD','POST','PUT','PATCH','DELETE','OPTIONS'].includes(req.method) ? req.method : 'OTHER';
      histogram.observe({method, route, status: String(res.writableFinished ? res.statusCode : 499)}, Number(process.hrtime.bigint()-start)/1e9);
    };
    res.once('finish',record); res.once('close',record); next();
  });
  new Gauge({ name:'hemia_db_pool_connections',help:'Application PostgreSQL pool state.',labelNames:['state'],registers:[registry],collect(){
    const pool = dataSource.driver.master;
    for(const [state,value] of Object.entries({total:pool.totalCount,idle:pool.idleCount,waiting:pool.waitingCount,max:pool.options.max})) this.set({state},value);
  }});
  const health = new Gauge({name:'hemia_dependency_up',help:'Last completed dependency probe, 1=healthy.',labelNames:['dependency'],registers:[registry]});
  const sampled = new Gauge({name:'hemia_dependency_sample_timestamp_seconds',help:'Time of last completed dependency sample.',labelNames:['dependency'],registers:[registry]});
  const states = outbox && new Gauge({name:'hemia_outbox_events',help:'Unfinished outbox events by state.',labelNames:['state'],registers:[registry]});
  const age = outbox && new Gauge({name:'hemia_outbox_oldest_timestamp_seconds',help:'Oldest unfinished outbox occurrence, zero if empty.',registers:[registry]});
  const probes = {database:()=>dataSource.query('SELECT 1'),...checks};
  if(outbox) probes.outbox = async()=>{
    const rows=await dataSource.query("SELECT status, count(*)::int AS count, extract(epoch from min(occurred_at))::float AS oldest FROM outbox_events WHERE status IN ('pending','publishing','failed','dead_letter') GROUP BY status");
    for(const status of ['pending','publishing','failed','dead_letter']) states.set({state:status}, Number(rows.find(r=>r.status===status)?.count??0));
    age.set(rows.length ? Math.min(...rows.map(r=>Number(r.oldest))) : 0);
  };
  // Single in-flight probe per dependency: a stalled pool cannot accumulate probes.
  const pending=new Set();
  const sample=()=>{for(const [name,probe] of Object.entries(probes)){
    if(pending.has(name))continue; pending.add(name);
    Promise.resolve().then(probe).then(result=>health.set({dependency:name},result===false?0:1),()=>health.set({dependency:name},0)).finally(()=>{sampled.set({dependency:name},Date.now()/1000);pending.delete(name)});
  }};
  for(const dependency of Object.keys(probes)){health.set({dependency},0);sampled.set({dependency},0);}
  const timer=setInterval(sample,15000);timer.unref();sample();
  const expected=Buffer.from('Bearer '+token);
  const server=createServer(async(req,res)=>{
    const actual=Buffer.from(req.headers.authorization||'');
    if(actual.length!==expected.length || !timingSafeEqual(actual,expected)){res.writeHead(401);res.end();return;}
    if(req.url!=='/metrics'||req.method!=='GET'){res.writeHead(404);res.end();return;}
    try{res.setHeader('Content-Type',registry.contentType);res.end(await registry.metrics());}catch{res.writeHead(503);res.end();}
  });
  server.requestTimeout=5000;server.headersTimeout=5000;
  try{await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,host,resolve);});}
  catch(error){clearInterval(timer);registry.clear();throw error;}
  const close=()=>{clearInterval(timer);server.close();server.closeAllConnections();registry.clear();};
  app.getHttpServer().once('close',close);
  return {registry,close};
}
module.exports={installMetrics};
